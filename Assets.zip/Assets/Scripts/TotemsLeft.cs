﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class TotemsLeft : MonoBehaviour
{

    public GameObject bulletPrefab;
    public Transform bulletPos;

    public float bulletTime;
    private float nextBulletTime;

    private void Update()
    {
        Keyboard kb = InputSystem.GetDevice<Keyboard>();
        Gamepad gamepad = InputSystem.GetDevice<Gamepad>();

        if (Time.time >= nextBulletTime)
        {
            Instantiate(bulletPrefab, bulletPos.position, bulletPos.rotation);
            nextBulletTime = Time.time + 1f / bulletTime;
        }
    }
}
