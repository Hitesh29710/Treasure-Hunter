﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerController : MonoBehaviour
{

    public float speed;
    public float jumpForce;
    private float inputX;
    public int Damage;

    private Rigidbody2D rb;

    private bool isGrounded;
    public Transform groundCheck;
    public float checkRadius;
    public LayerMask whatIsGround;
    public Transform Effect;

    private bool facingRight = true;

    private Animator anim;

    public int maxHealth = 100;
    private int currentHealth;

    public HealthBar healthBar;

    private bool spawnDust;
    public GameObject landEffect;
    public GameObject jumpEffect;
    public GameObject runEffect;

    public float timeBtwTrail;
    private float starTimeBtwTrail;

    public Animator camAnim;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        currentHealth = maxHealth;
        healthBar.SetMaxHealth(maxHealth);
    }

    private void FixedUpdate()
    {
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, checkRadius, whatIsGround);

        rb.velocity = new Vector2(inputX * speed, rb.velocity.y);

        if(facingRight == false && inputX > 0)
        {
            Flip();
        }

        if(facingRight == true && inputX < 0)
        {
            Flip();
        }
    }

    private void Update()
    {
        Keyboard kb = InputSystem.GetDevice<Keyboard>();
        Gamepad gamepad = InputSystem.GetDevice<Gamepad>();

        if (isGrounded == true)
        {
            anim.SetBool("isJumping", false);
            if (spawnDust == true)
            {
                camAnim.SetTrigger("Shake");
                Instantiate(landEffect, Effect.position, Quaternion.identity);
                spawnDust = false;
            }
        }
        else
        {
            anim.SetBool("isJumping", true);
            spawnDust = true;
        }

        if(inputX == 0)
        {
            anim.SetBool("isRunning", false);
        }else
        {
            anim.SetBool("isRunning", true);
        }

        if(kb.wKey.wasPressedThisFrame || gamepad.buttonSouth.wasPressedThisFrame && isGrounded == true)
        {
            anim.SetTrigger("takeOf");
        }

        if(isGrounded == true && kb.wKey.wasPressedThisFrame || gamepad.buttonSouth.wasPressedThisFrame)
        {
            Instantiate(jumpEffect, Effect.position, Quaternion.identity);
        }

        if (inputX != 0)
        {
            if (timeBtwTrail <= 0)
            {
                Instantiate(runEffect, groundCheck.position, Quaternion.identity);
                timeBtwTrail = starTimeBtwTrail;
            }
            else
            {
                timeBtwTrail -= Time.deltaTime;
            }
        }
    }

    public void Move(InputAction.CallbackContext ctx)
    {
        inputX = ctx.ReadValue<Vector2>().x;
    }

    private void Flip()
    {
        facingRight = !facingRight;

        transform.Rotate(0f, 180f, 0f);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {

        if (collision.gameObject.tag == "Enemy")
        {
            GetComponent<PlayerDamage>().TakeDamage(Damage);
            TakeDamage(25);
        }

    }

    public void Jump(InputAction.CallbackContext ctx)
    {
        if(ctx.performed && isGrounded)
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpForce);
        }
    }

    private void TakeDamage(int damage)
    {
        currentHealth -= damage;

        healthBar.SetHealth(currentHealth);
    }
}
