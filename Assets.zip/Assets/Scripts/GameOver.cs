﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameOver : MonoBehaviour
{
    
    public void Exit()
    {
        SceneManager.LoadScene("Menu");
    }

    public void Setting()
    {
        Debug.Log("Settings");
    }

    public void PlayAgain()
    {
        SceneManager.LoadScene("Story Mode");
    }

}
