﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class TotemsRight : MonoBehaviour
{

    public GameObject bulletPrefab1;
    public Transform bulletPos1;

    public float bulletTime1;
    private float nextBulletTime1;

    private void Update()
    {
        Keyboard kb = InputSystem.GetDevice<Keyboard>();
        Gamepad gamepad = InputSystem.GetDevice<Gamepad>();

        if (Time.time >= nextBulletTime1)
        {
            Instantiate(bulletPrefab1, bulletPos1.position, bulletPos1.rotation);
            nextBulletTime1 = Time.time + 1f / bulletTime1;
        }
    }
}
