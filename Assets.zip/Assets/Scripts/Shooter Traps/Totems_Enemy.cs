﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Totems_Enemy : MonoBehaviour
{

    public Animator anim;

    public int maxHealth = 100;
    private int currentHealth;

    public GameObject dieEffect;

    private void Start()
    {
        currentHealth = maxHealth;
    }

    public void TakeDamage(int damage)
    {
        currentHealth -= damage;

        anim.SetTrigger("Hurt");

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    private void Die()
    {
        Instantiate(dieEffect, transform.position, Quaternion.identity);

        this.enabled = false;
        GetComponent<EnemyBehaviour>().enabled = false;
    }

}
