﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.InputSystem;

public class PauseMenu : MonoBehaviour
{

    public static bool gameIsPaused = false;
    public AudioMixer audioMixer;

    public GameObject pauseMenuUI;

    private void Update()
    {
        Keyboard kb = InputSystem.GetDevice<Keyboard>();
        Gamepad gamepad = InputSystem.GetDevice<Gamepad>();

        if(kb.escapeKey.wasPressedThisFrame)
        {
            if(gameIsPaused)
            {
                Resume();
            }else
            {
                Pause();
            }
        }

    }

    private void Resume()
    {
        pauseMenuUI.SetActive(false);
        Time.timeScale = 1;
        gameIsPaused = false;
    }

    private void Pause()
    {
        pauseMenuUI.SetActive(true);
        Time.timeScale = 0;
        gameIsPaused = true;
    }

    public void SetVolume (float volume)
    {
        audioMixer.SetFloat("volume", volume);
    }

}
